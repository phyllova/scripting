-- phpMyAdmin SQL Dump
-- version 4.5.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jul 08, 2020 at 01:07 AM
-- Server version: 5.7.11
-- PHP Version: 5.6.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `empiretrades`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `email` varchar(150) NOT NULL,
  `password` varchar(100) NOT NULL,
  `wallet` varchar(200) NOT NULL,
  `name` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `email`, `password`, `wallet`, `name`) VALUES
(1, 'support@empiretradingpro.com', '$2y$10$jPBT7f0uBNwOE.2UDOY1wOlumdArJhlzreXMakjpvkN75YgkIUUie', '37gtDFxgUFovSpUqiiTJ91w7tWB8Jy6wH3', 'Administrator');

-- --------------------------------------------------------

--
-- Table structure for table `members`
--

CREATE TABLE `members` (
  `id` int(11) NOT NULL,
  `account_id` varchar(20) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `plan` varchar(150) NOT NULL,
  `country` varchar(150) NOT NULL,
  `bank` varchar(150) NOT NULL,
  `account_name` varchar(150) NOT NULL,
  `account_number` varchar(150) NOT NULL,
  `ssn` varchar(150) NOT NULL,
  `pobox` varchar(150) NOT NULL,
  `token` varchar(150) NOT NULL,
  `status` int(10) NOT NULL,
  `date` varchar(100) NOT NULL,
  `password` varchar(150) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `members`
--

INSERT INTO `members` (`id`, `account_id`, `name`, `email`, `phone`, `plan`, `country`, `bank`, `account_name`, `account_number`, `ssn`, `pobox`, `token`, `status`, `date`, `password`) VALUES
(11, 'sw8MuG', 'Dennis Orezi', 'orezidennis@yahoo.com', '', '', 'France', '', '', '', '', '', 'hXaik8kmP3kj', 1, '2020-07-06 12:46:25pm', '$2y$10$vpXP0IOUphDoUXmSF36qieJAFPlKQ8BYZhimDzkrzPiBpzw5ckTCu'),
(10, '999L3h', 'AGOGO COLLINS', 'agogocollins80@gmail.com', '08149988397', 'Gold Plan', 'Nigeria', 'GTbank', 'Agogo Collins Nyerhovwo', '345465767868', '', '', 'MtnkGNcwIF7z', 1, '2020-07-06 06:08:22am', '$2y$10$vKW5EcJYu8BKcEJD1kXXXuGJf5QzaVAEd2VA9hgmiDCp/HnYxYk7y');

-- --------------------------------------------------------

--
-- Table structure for table `trades`
--

CREATE TABLE `trades` (
  `id` int(11) NOT NULL,
  `date` varchar(100) NOT NULL,
  `transact_id` varchar(100) NOT NULL,
  `client_id` varchar(100) NOT NULL,
  `status` varchar(50) NOT NULL,
  `balance` varchar(100) NOT NULL,
  `profit` varchar(100) NOT NULL,
  `bonus` varchar(150) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `trades`
--

INSERT INTO `trades` (`id`, `date`, `transact_id`, `client_id`, `status`, `balance`, `profit`, `bonus`) VALUES
(2, '2020-07-06 06:30:53am', '823213071373', '999L3h', 'Completed', '23000', '1000', ''),
(3, '2020-07-06 06:34:25am', '750925897283', '999L3h', 'Completed', '239000', '20000', ''),
(4, '2020-07-06 07:18:32am', '185514748794', '999L3h', 'Completed', '10400', '3000', '1000'),
(7, '2020-07-06 01:02:58pm', '887534714308', 'sw8MuG', 'Completed', '231000', '80299', '10401');

-- --------------------------------------------------------

--
-- Table structure for table `withrawals`
--

CREATE TABLE `withrawals` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `phone` varchar(150) NOT NULL,
  `bank` varchar(100) NOT NULL,
  `account` varchar(100) NOT NULL,
  `number` varchar(100) NOT NULL,
  `account_id` varchar(100) NOT NULL,
  `amount` varchar(100) NOT NULL,
  `type` varchar(50) NOT NULL,
  `date` varchar(200) NOT NULL,
  `transact_id` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `withrawals`
--

INSERT INTO `withrawals` (`id`, `name`, `email`, `phone`, `bank`, `account`, `number`, `account_id`, `amount`, `type`, `date`, `transact_id`, `status`) VALUES
(5, 'AGOGO COLLINS', 'agogocollins80@gmail.com', '08149988397', 'GTbank', 'Agogo Collins Nyerhovwo', '3876866878', 'gI9gHX', '45000', 'withdrawal', '2020-07-05 07:32:25pm', '827692600231', 'sent'),
(4, 'AGOGO COLLINS', 'agogocollins80@gmail.com', '08149988397', 'GTbank', 'Agogo Collins Nyerhovwo', '3876866878', 'gI9gHX', '2000', 'withdrawal', '2020-07-05 07:29:54pm', '476499852544', 'sent'),
(18, 'AGOGO COLLINS', 'agogocollins80@gmail.com', '08149988397', '', '', '', '999L3h', '200', 'Deposit', '2020-07-07 08:04:45am', '650751102020', 'sent'),
(16, 'Dennis Orezi', 'orezidennis@yahoo.com', 'N/A', 'N/A', 'N/A', 'N/A', 'sw8MuG', '1000', 'Withdrawal', '2020-07-06 12:49:20pm', '674005346764', 'sent'),
(17, 'Dennis Orezi', 'orezidennis@yahoo.com', 'N/A', '', '', '', 'sw8MuG', '23000', 'Deposit', '2020-07-06 01:04:59pm', '990114736828', 'sent');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `members`
--
ALTER TABLE `members`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `trades`
--
ALTER TABLE `trades`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `withrawals`
--
ALTER TABLE `withrawals`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `members`
--
ALTER TABLE `members`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `trades`
--
ALTER TABLE `trades`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `withrawals`
--
ALTER TABLE `withrawals`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

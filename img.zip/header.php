 <header id="header" class="header_section bd-bottom">
<div class="top_header">
<div class="container">
<div class="top_content_wrap row">
<div class="col-sm-8">
<ul class="left_info">
<li><a href="#"><i class="ti-email"></i>Support@iqoptionsforex.com</a></li>
<li><a href="#"><i class="ti-mobile"></i>+(333) 052 39876</a></li>
</ul>
</div>
<div class="col-sm-4 d-none d-md-block" style="display: block !important">
<ul class="right_info">
<li><a href="access/login.php"><i class="ti-user"></i>Login</a></li>
<li><a href="access/register.php"><i class="ti-pencil-alt"></i>Register</a></li>
</ul>
</div>
</div>
</div>
</div>
<div class="bottom_header">
<div class="container">
<div class="bottom_content_wrap row">
<div class="col-sm-4">
	<img src="img/logo.png" width="150">
</div>
<div class="col-sm-8 text-right">
<ul id="mainmenu" class="nav navbar-nav nav-menu">
<li> <a href="index.php">Home</a></li>
<li class="active"><a href="about.php">About</a></li>
<li><a href="packages.php">Investment Plan</a></li>
</ul>
<a href="access/register.php" class="button_1">Register Now</a>
</div>
</div>
</div>
</div>
</header>
<section class="widget_section padding" style="padding: 52px 0;">
        <div class="container">
        <div class="row widget_wrapper">
        <div class="col-lg-4 col-sm-6 sm-padding">
            <img src="img/logo.png" width="100">
        <p>Iqoptions Forex is a company formed by a team of PROFESSIONAL TRADERS
    with EXPERTISE in one of the biggest financial markets of today,
    the CRYPTOCURRENCY and FOREX. Our focus is to provide our investors with daily
    and constant profits in these markets. </p>

    <h2 class="mb-10" style="color: #fff; text-transform: inherit">Licence</h2>

     <p>Iqoptions Forex is a fully certified and licensed company. Our license number is <b>#11008971</b></p>
        </div>
        <div class="col-lg-4 col-sm-6 sm-padding">
        <h3>Company</h3>
        <ul class="widget_links">
        <li><a href="#">About Us</a></li>
        <li><a href="#">Investment Plan</a></li>
        <li><a href="#">Our Services</a></li>
        <li><a href="#">Contact</a></li>
        </ul>
        </div>
        
        <div class="col-lg-4 col-sm-6 sm-padding">
        <h3>Subscribe Newslatters</h3>
        <p>With our newslatters we can keep you updated</p>
        <div class="subscribe_form" novalidate="true">
        <form action="#" class="subscribe_form" novalidate="true">
        <input type="email" name="EMAIL" id="subs-email" class="form_input" placeholder="Email Address...">
        <button type="submit" class="submit">SUBSCRIBE</button>
        <div class="clearfix"></div>
        <div id="subscribe-result">
        <p class="subscription-success"></p>
        <p class="subscription-error"></p>
        </div>
        </form>
        </div>
        </div>
        </div>
        </div>
        </section>
        <footer class="footer_section">
        <div class="container">
        <div class="copyright" style="text-transform: inherit;">All rights reserved © 2021 Iqptions Forex/div>
        </div>
        </footer>